/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_281()
{
    return 3251079496U;
}

unsigned addval_303(unsigned x)
{
    return x + 2423815340U;
}

unsigned getval_205()
{
    return 2428995912U;
}

unsigned getval_251()
{
    return 3281032280U;
}

void setval_262(unsigned *p)
{
    *p = 2421709170U;
}

unsigned addval_382(unsigned x)
{
    return x + 3284633928U;
}

void setval_249(unsigned *p)
{
    *p = 3084632920U;
}

unsigned getval_151()
{
    return 2445773128U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_180(unsigned x)
{
    return x + 3223374505U;
}

void setval_128(unsigned *p)
{
    *p = 3286280520U;
}

void setval_258(unsigned *p)
{
    *p = 3221801608U;
}

void setval_441(unsigned *p)
{
    *p = 3767093391U;
}

unsigned addval_375(unsigned x)
{
    return x + 3380923033U;
}

unsigned addval_168(unsigned x)
{
    return x + 3526937225U;
}

unsigned getval_465()
{
    return 2430634248U;
}

void setval_280(unsigned *p)
{
    *p = 3281046153U;
}

void setval_191(unsigned *p)
{
    *p = 3526934921U;
}

unsigned getval_413()
{
    return 2497087913U;
}

unsigned addval_118(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_412()
{
    return 3281174921U;
}

void setval_384(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_334(unsigned x)
{
    return x + 3221804745U;
}

unsigned addval_170(unsigned x)
{
    return x + 3380923081U;
}

unsigned getval_209()
{
    return 3286272332U;
}

unsigned addval_467(unsigned x)
{
    return x + 3284249060U;
}

unsigned getval_203()
{
    return 3229931145U;
}

unsigned addval_458(unsigned x)
{
    return x + 3223377561U;
}

unsigned getval_494()
{
    return 2425473673U;
}

void setval_125(unsigned *p)
{
    *p = 3286272320U;
}

void setval_346(unsigned *p)
{
    *p = 3221799305U;
}

unsigned addval_259(unsigned x)
{
    return x + 3758704848U;
}

unsigned getval_360()
{
    return 3675832713U;
}

unsigned addval_104(unsigned x)
{
    return x + 3677935233U;
}

unsigned addval_242(unsigned x)
{
    return x + 3532969609U;
}

unsigned getval_488()
{
    return 3281046157U;
}

unsigned addval_140(unsigned x)
{
    return x + 2428606781U;
}

unsigned addval_252(unsigned x)
{
    return x + 3682915977U;
}

void setval_234(unsigned *p)
{
    *p = 3523794585U;
}

unsigned getval_230()
{
    return 3682910605U;
}

void setval_462(unsigned *p)
{
    *p = 3224945025U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
